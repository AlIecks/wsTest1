# About the models

Below is the list of all Excel models that are part of the article "Cash flow financial modeling 101 for legacy commercial banking" and this archive. The latest version of the article can be found in the [knowledge section](https://anxtream.com/knowledge) of the [anxtream](https://anxtream.com) website.

| # | Name | Description |
| ---- | ---- | ---- |
| 1. | Wb_1_RWA.xlsm | Illustration of RWA calculation |
| 2. | Wb_2_LCR.xlsm | Illustration of LCR calculation |
| 3. | Wb_3_NSFR.xlsm | Illustration of NSFR calculation |
| 4. | Wb_4_Plain_vanilla_banking_model.xlsm | Basic commercial banking engine |
| 5. | Wb_5_Credit_risk_accounting_added.xlsm | Above + credit risk accounting |
| 6. | Wb_6_Capital_regulation_added.xlsm | Above + capital regulation |
| 7. | Wb_7_Liquidity_regulation_added.xlsm | Above + liquidity |
| 8. | Wb_8_FCFE_valuation_added.xlsm | Above + basic FCFE valuation |
| 9. | Wb_9_Final_model.xlsm | Full-fledged commercial banking model |

## Disclaimer

**No guarantee** The models are provided without any guarantee whatsoever. I made good effort to make the models error-free, but I cannot guarantee absolutely the absence of errors there. Thus, if you use any of these models, you acknowledge that you do it at your own risk. That said, you are totally free to use the models any way you like, with or without any reference to me or anxtream.

**Fictitious data** All models use hypothetical input data, employed for illustrative purposes only. I can't guarantee any reliability of input data. Thus if you use any of these models for your own purposes, a thorough revision of the input data is highly recommended.

**VBA** The models intentionally rely on VBA for some macros and user-defined functions. It's possible to turn the VBA off without severely affecting the core functions of the models. However this may result in some minor problems with displaying the text labels in the models.

See you on the other side,

Brds
Alex
[in/alexander-korotkov](https://www.linkedin.com/in/alexander-korotkov/)
